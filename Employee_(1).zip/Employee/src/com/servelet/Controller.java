package com.servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.AssociateDao;
import com.beans.Associate;

/**
 * Servlet implementation class Controller
 */
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println("hai" +action);
		if("createassociate".equals(action))
		{
			Associate a=new Associate();
			a.setName(request.getParameter("name"));
			a.setEmpid(Integer.parseInt(request.getParameter("Empid")));
			a.setIlpLocation(request.getParameter("ILPLocation"));
			a.setIlpBatch(request.getParameter("ILPBatch"));
			String set=" ";
			String[] skill=request.getParameterValues("Skillset");
			for(String m:skill)
			{
				set=set+m+" ";
			}
		    a.setSkillSet(set);
		    
		    
			a.setGender(request.getParameter("gender"));
			AssociateDao b=new AssociateDao();
			try {
				int count=b.createAssociate(a);
				if(count>0){
					System.out.println(count);
					request.setAttribute("Msg", "associate Inserted Successfully\n Please Note Ur associate Id");
					request.setAttribute("Id", count);
					RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
				}
				else{
					request.setAttribute("Msg", "Sorry failed to regiseter Please Try again");
					RequestDispatcher rd=request.getRequestDispatcher("Failure.jsp");
					rd.forward(request, response);
					
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			else if("viewdetails".equals(action))
			{
			int Employeeid=(Integer.parseInt(request.getParameter("Empid")));
		
		   AssociateDao ad=new AssociateDao();
		    ArrayList<Associate> alist = null;
			try {
				alist = ad.viewAssociateDetails(Employeeid);
			
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    request.setAttribute("alist",alist);
	        RequestDispatcher r=request.getRequestDispatcher("result1.jsp");
	        r.forward(request,response);
	        
				
			
		}
		else 
		{
		
		String Name=request.getParameter("name");
		AssociateDao ad=new AssociateDao();
	try {
		int count=ad.searchAssociate(Name);
		System.out.println("ds"+count);
		if(count>0)
		{
			PrintWriter p=response.getWriter();
			p.println("The search name is there");
		}
		else
		{
			PrintWriter p=response.getWriter();
			p.println("The search name is not there");	
		}
	    } catch (ClassNotFoundException | SQLException e) 
	    {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
		
	
	}
}