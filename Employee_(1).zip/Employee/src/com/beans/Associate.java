package com.beans;

public class Associate {
	private String name;
	private int Empid;
	private String ilpLocation;
	private String ilpBatch;
	private String skillSet;
	private String gender;
	public Associate(String name, int empid, String ilpLocation,
			String ilpBatch, String skillSet, String gender) {
		super();
		this.name = name;
		Empid = empid;
		this.ilpLocation = ilpLocation;
		this.ilpBatch = ilpBatch;
		this.skillSet = skillSet;
		this.gender = gender;
	}
	public Associate() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getIlpLocation() {
		return ilpLocation;
	}
	public void setIlpLocation(String ilpLocation) {
		this.ilpLocation = ilpLocation;
	}
	public String getIlpBatch() {
		return ilpBatch;
	}
	public void setIlpBatch(String ilpBatch) {
		this.ilpBatch = ilpBatch;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	

}
