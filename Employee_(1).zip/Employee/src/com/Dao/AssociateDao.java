package com.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.beans.Associate;
import com.connection.DataBaseUtil;

public class AssociateDao {
	static Connection con=null;
	static PreparedStatement ps=null;
	static ResultSet rs=null;
	static Statement st=null;
	static int count;
	
	public int createAssociate(Associate a) throws SQLException,ClassNotFoundException {
		try
		{
		con=DataBaseUtil.getConnection();
			ps=con.prepareStatement("INSERT INTO  ASSOCIATE VALUES(?,?,?,?,?,?)");
			ps.setString(1,a.getName());
			ps.setInt(2,a.getEmpid());
			ps.setString(3,a.getIlpLocation());
			ps.setString(4,a.getIlpBatch());
			ps.setString(5,a.getSkillSet());
			System.out.println(a.getSkillSet());
			ps.setString(6,a.getGender());
			count=ps.executeUpdate();
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				DataBaseUtil.closePreparedStatement(ps);
				DataBaseUtil.closeConnection(con);
			
		    }
		return count;
		}

	public String get(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public int searchAssociate(String name)throws SQLException,ClassNotFoundException{
		try
		{
			System.out.println("name"+name);
		con=DataBaseUtil.getConnection();
		ps=con.prepareStatement("Select * from  ASSOCIATE where name=?");
		ps.setString(1,name);
		count=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DataBaseUtil.closePreparedStatement(ps);
			DataBaseUtil.closeConnection(con);
		
	    }
		System.out.println("the count is"+count);
	return count;
	
		
	}

	public ArrayList<Associate> viewAssociateDetails(int Empid)throws SQLException,ClassNotFoundException {
		ArrayList<Associate> mlist=new ArrayList<Associate>();
		try
		{
			con=DataBaseUtil.getConnection();
			ps=con.prepareStatement("  select * from ASSOCIATE where EMPID=?");
		
			ps.setInt(1,Empid);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Associate t=new Associate();
				t.setName(rs.getString(1));
				t.setEmpid(rs.getInt(2));
				t.setIlpLocation(rs.getString(3));
				t.setIlpBatch(rs.getString(4));
				t.setSkillSet(rs.getString(5));
				t.setGender(rs.getString(6));
				mlist.add(t);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DataBaseUtil.closeConnection(con);
			DataBaseUtil.closePreparedStatement(ps);
		}
		
	return mlist;
	
			
			}
	}
