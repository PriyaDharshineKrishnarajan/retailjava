package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataBaseUtil {
	private static final String drivername="oracle.jdbc.driver.OracleDriver";
	private static final String url="jdbc:oracle:thin:@inchnilpdb03.India.TCS.com:1521:JavaDB03";
	private static final String username="E1129877";
	private static final String password="E1129877";
	static Connection con=null;
	static PreparedStatement ps=null;
	static ResultSet rs=null;
	public static Connection getConnection() throws SQLException,ClassNotFoundException
	{
		try
		{
		Class.forName(drivername);
		con=DriverManager.getConnection(url,username,password);
		}catch(SQLException e){
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		return con;
	}
	public static void closePreparedStatement(PreparedStatement ps) throws SQLException,ClassNotFoundException
	{
		try
		{
			if(ps!=null)
			{
				ps.close();
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	}
	public static void closeResulSet(ResultSet rs) throws SQLException,ClassNotFoundException
	{
		try
		{
			if(rs!=null)
			{
				rs.close();
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	}
	public static void closeConnection(Connection con) throws SQLException,ClassNotFoundException
	{
		try
		{
			if(con!=null)
			{
				con.close();
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
	}


}
