package Main;

import java.util.ArrayList;
import java.util.Scanner;

import Service.Dao;
import Bean.Student;

public class Studentlist {
	public static void main(String[] args) {
		
	      Student s1=new Student(101,"priya");
	      Student s2=new Student(102,"divya");
	      Student s3=new Student(103,"ramya");
	      Student s4=new Student(104,"viji");
	      
	      ArrayList<Student> r=new ArrayList<Student>();
	      r.add(s1);
	      r.add(s2);
	      r.add(s3);
	      r.add(s4);
	      Dao s=new Dao();
	      ArrayList<Student> t=new ArrayList<Student>();
	      System.out.println("Enter employee id");
	      Scanner sc=new Scanner(System.in);
	      int empid=sc.nextInt();
	      t=s.retriveid(r,empid);

	      for(Student q:t)
	    	  {
	    	  System.out.println("Employee id is:" +q.getId());
	    	  System.out.println("Name is:" +q.getName());
	    	 }
	    		  
	    	  }
	      
		

}
