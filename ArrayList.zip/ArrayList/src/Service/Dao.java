package Service;

import java.util.ArrayList;

import Bean.Student;

public class Dao {
	public ArrayList<Student> retriveid(ArrayList<Student> r, int i) {
		 ArrayList<Student> p=new ArrayList<Student>();
		for(Student m:r)
		{
			if(m.getId()==i)
				p.add(m);
		}
		return p;
			
	}

}
